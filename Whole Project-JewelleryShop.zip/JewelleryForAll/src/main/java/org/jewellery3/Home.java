package org.jewellery3;

public class Home {

public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}

private String image;

}
